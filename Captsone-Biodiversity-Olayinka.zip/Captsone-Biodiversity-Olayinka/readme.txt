I also completed the project on codecademy.com
There might be slight differences between the two methods.

Thank you!
